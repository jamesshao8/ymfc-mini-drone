# ymfc-mini-drone
mini-drone (hardware design and software modification), based on ymfc-32
